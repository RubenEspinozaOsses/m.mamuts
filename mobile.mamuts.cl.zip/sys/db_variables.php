<?php
define('NOMBRE_SERVIDOR','localhost');
define('NOMBRE_USUARIO','mamutscl_merlin');
define('PASSWORD','miguel1967');
define('NOMBRE_BASE_DATOS','mamutscl_bdmamuts');
define("SERVIDOR", '');
define("tiempo_sesion", 60*60*2);


?>